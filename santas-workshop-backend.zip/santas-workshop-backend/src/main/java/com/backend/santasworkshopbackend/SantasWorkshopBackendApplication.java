package com.backend.santasworkshopbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SantasWorkshopBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SantasWorkshopBackendApplication.class, args);
	}

}
