package com.backend.santasworkshopbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SantasWorkshopBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
